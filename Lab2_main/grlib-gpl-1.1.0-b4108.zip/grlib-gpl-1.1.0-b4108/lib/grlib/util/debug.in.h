
#ifndef CONFIG_DEBUG_UART
#define CONFIG_DEBUG_UART 0
#endif
