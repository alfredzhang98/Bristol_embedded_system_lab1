#ifndef CONFIG_CAN_ENABLE
#define CONFIG_CAN_ENABLE 0
#endif

#ifndef CONFIG_CANIO
#define CONFIG_CANIO 0
#endif

#ifndef CONFIG_CANIRQ
#define CONFIG_CANIRQ 0
#endif

#ifndef CONFIG_CANLOOP
#define CONFIG_CANLOOP 0
#endif

#ifndef CONFIG_CAN_SYNCRST
#define CONFIG_CAN_SYNCRST 0
#endif


#ifndef CONFIG_CAN_FT
#define CONFIG_CAN_FT 0
#endif
