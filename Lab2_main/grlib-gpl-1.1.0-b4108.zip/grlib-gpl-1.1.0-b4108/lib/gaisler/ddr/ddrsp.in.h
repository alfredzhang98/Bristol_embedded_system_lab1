#ifndef CONFIG_DDRSP
#define CONFIG_DDRSP 0
#endif

#ifndef CONFIG_DDRSP_INIT
#define CONFIG_DDRSP_INIT 0
#endif

#ifndef CONFIG_DDRSP_FREQ
#define CONFIG_DDRSP_FREQ 100
#endif

#ifndef CONFIG_DDRSP_COL
#define CONFIG_DDRSP_COL 9
#endif

#ifndef CONFIG_DDRSP_MBYTE
#define CONFIG_DDRSP_MBYTE 8
#endif

#ifndef CONFIG_DDRSP_RSKEW
#define CONFIG_DDRSP_RSKEW 0
#endif
