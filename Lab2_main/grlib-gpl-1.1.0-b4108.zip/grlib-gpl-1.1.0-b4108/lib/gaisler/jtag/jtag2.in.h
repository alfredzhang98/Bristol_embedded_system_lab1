#ifndef CONFIG_DSU_JTAG2
#define CONFIG_DSU_JTAG2 0
#endif

