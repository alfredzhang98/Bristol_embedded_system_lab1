#ifndef CONFIG_DSU_JTAG
#define CONFIG_DSU_JTAG 0
#endif

