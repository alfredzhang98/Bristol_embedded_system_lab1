These are four simple tests for the oc can core which you can run on 
hardware and in simulation.

You should compile them as follows:

sparc-elf-gcc -O2 -msoft-float -g  can_send_basic.c  -o can_send_basic.exe

For further information read the header in the test files.
  