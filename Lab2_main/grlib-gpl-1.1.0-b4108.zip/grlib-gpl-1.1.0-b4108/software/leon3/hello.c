
main()
{
	printf("Hello World\n");
}
